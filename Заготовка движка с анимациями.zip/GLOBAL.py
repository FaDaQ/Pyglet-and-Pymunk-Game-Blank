import pyglet
import pymunk

from Base import GameManager
from Base.GameApp import GameApp
from Game.Camera import Camera

PYMUNK_SPACE = pymunk.Space()
PYMUNK_SPACE.gravity = 0, -999
PYMUNK_SPACE.damping = 0.1

MAIN_BATCH = pyglet.graphics.Batch()
APP = GameApp(MAIN_BATCH, PYMUNK_SPACE, vsync=False)
CAMERA = Camera(APP)
GAME_MANAGER = GameManager(APP, CAMERA)

KEYS = pyglet.window.key.KeyStateHandler()
APP.push_handlers(KEYS)


PLAYER_COLLISION = 1
PLATFORM_COLLISION = 2

KEY_PRESSED = 1
KEY_RELEASED = 2
MOUSE_PRESSED = 3
MOUSE_RELEASED = 4
MOUSE_MOTION = 5
MOUSE_DRAG = 6
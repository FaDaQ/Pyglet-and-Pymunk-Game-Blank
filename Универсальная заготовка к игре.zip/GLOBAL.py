import pyglet
import pymunk

from Base.GameApp import GameApp


PYMUNK_SPACE = pymunk.Space()
PYMUNK_SPACE.gravity = 0, -9
PYMUNK_SPACE.damping = 0.1

MAIN_BATCH = pyglet.graphics.Batch()
APP = GameApp(MAIN_BATCH, PYMUNK_SPACE, vsync=False)

KEYS = pyglet.window.key.KeyStateHandler()
APP.push_handlers(KEYS)


PLAYER_COLLISION = 1
PLATFORM_COLLISION = 2

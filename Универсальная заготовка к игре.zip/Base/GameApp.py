import pyglet
import pymunk.pyglet_util


draw_options = pymunk.pyglet_util.DrawOptions()

class GameApp(pyglet.window.Window):
    def __init__(self, main_batch: pyglet.graphics.Batch, space: pymunk.Space, width=1280, height=720, title="Pyglet - GameApp", fps=9999,
                 **kwargs):
        super().__init__(width, height, caption=title, **kwargs)
        self.batch = main_batch
        self.space = space
        self.__max_fps = fps
        self.__fixed_update_fps = 120

        self.__objects = set()


    def on_draw(self):
        self.clear()
        self.batch.draw()
        self.space.debug_draw(draw_options)

    def update(self, dt):
        [obj.update() for obj in self.__objects]

    def fixed_update(self, dt):
        self.space.step(dt)
        [obj.fixed_update() for obj in self.__objects]

    def get_batch(self):
        return self.batch

    def run(self):
        pyglet.clock.schedule(self.update)
        pyglet.clock.schedule_interval(self.fixed_update, 1 / self.__fixed_update_fps)
        pyglet.app.run(interval=1 / self.__max_fps)

    def add_object(self, obj):
        self.__objects.add(obj)
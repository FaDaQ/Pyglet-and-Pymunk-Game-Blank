from GLOBAL import *

APP.run()
from typing import TYPE_CHECKING

if TYPE_CHECKING:
    from Base.GameObject import GameObject


class Component:
    def __init__(self, name: str, game_object: 'GameObject'):
        self.name = name
        self.gameObject = game_object

    def update(self):
        pass

    name: str
    gameObject: 'GameObject'